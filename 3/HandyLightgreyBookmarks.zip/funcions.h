void fnc_add_company(vector <Company> &empresas,int &qnt_empresas);
void fnc_add_employee(vector <Company> empresas,int qnt_empresas);
void fnc_list_emp(vector <Company> empresas,int qnt_empresas);
void fnc_list_exp_emp();
void fnc_calc_average();
void fnc_back();