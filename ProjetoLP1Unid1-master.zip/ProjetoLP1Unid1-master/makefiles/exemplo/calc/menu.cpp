#include <iostream>

#include "sum.h"
#include "sub.h"
#include "mul.h"
#include "div.h"

int main () {

	std::cout << "Choose the operation desired: \n1-> Sum.\n2-> Subtraction.\n3-> Multiplication.\n4-> Division." << std::endl;

	int x = 0;

	std::cin >> x;

	if (x = 1) {
		fnc_sum();
	} else if (x = 2) {
		fnc_sub();
	} else if (x = 3) {
		fnc_mul();
	} else if (x = 4) {
		fnc_div();
	} else {
		std::cout << "ERROR" << std::endl;
	}


	return 0;
}

